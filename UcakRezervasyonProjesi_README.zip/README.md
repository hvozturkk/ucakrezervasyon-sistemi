# Uçak Bilet Rezervasyon Sistemi (Java Console App)

Bu proje, Java dilinde nesne yönelimli programlama (OOP) prensiplerine uygun olarak geliştirilmiş bir uçak bileti rezervasyon sistemidir. Konsol tabanlı arayüz ile çalışmaktadır.

## Özellikler
- Uçak, Lokasyon, Uçuş ve Rezervasyon nesne modelleri
- Koltuk kapasitesi kontrolü
- Konsoldan rezervasyon yapma ve listeleme
- Uçuş ve uçak ekleme
- JSON formatında rezervasyon kaydı ve okuma (Gson kullanıldı)
- CSV formatında dışa veri aktarımı
- Abstract class ve interface kullanımı ile sağlam OOP altyapısı

## Kullanılan Teknolojiler
- Java (JDK 8+)
- Gson kütüphanesi (JSON işlemleri için)
- Dosya I/O (FileWriter / FileReader)
- LocalDateTime sınıfı (Uçuş zamanı için)

## Nasıl Çalıştırılır
1. Projeyi `git clone` veya `.zip` olarak indirip açın.
2. Java destekli bir IDE (IntelliJ IDEA, Eclipse) ile açın.
3. `Main.java` dosyasını çalıştırın.
4. Konsol üzerinden işlem yapabilirsiniz.

## Örnek Menü
```
1. Uçuşları Listele
2. Rezervasyon Yap
3. Rezervasyonları Listele
4. Rezervasyonları JSON'a Kaydet
5. Yeni Uçak Ekle
6. Yeni Uçuş Ekle
7. JSON'dan Rezervasyonları Yükle
8. CSV'ye Kaydet
0. Çıkış
```

## Geliştirici
- Ad Soyad: [Senin Adın]
- Öğrenci No: [Numaran]
- Dönem: 2025 Bahar

## Notlar
- `gson-2.10.1.jar` kütüphanesi, JSON işlemleri için kullanılmaktadır.
- JSON ve CSV dosyaları çalıştırma dizinine kaydedilir.