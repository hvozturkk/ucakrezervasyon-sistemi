import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class FileHelper {

    public static void rezervasyonlariKaydet(List<Rezervasyon> rezervasyonlar, String dosyaAdi) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter(dosyaAdi)) {
            gson.toJson(rezervasyonlar, writer);
            System.out.println("Rezervasyonlar başarıyla '" + dosyaAdi + "' dosyasına kaydedildi.");
        } catch (IOException e) {
            System.out.println("Dosya yazma hatası: " + e.getMessage());
        }
    }

    public static List<Rezervasyon> rezervasyonlariOku(String dosyaAdi) {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader(dosyaAdi)) {
            return gson.fromJson(reader, new TypeToken<List<Rezervasyon>>() {}.getType());
        } catch (IOException e) {
            System.out.println("Dosya okunamadı: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}