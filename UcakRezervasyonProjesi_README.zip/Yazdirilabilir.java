public interface Yazdirilabilir {
    void yazdir();
}