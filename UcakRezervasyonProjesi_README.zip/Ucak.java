public class Ucak extends BaseEntity implements Yazdirilabilir {
    private String model;
    private String marka;
    private String seriNo;
    private int koltukKapasitesi;

    public Ucak(String model, String marka, String seriNo, int koltukKapasitesi) {
        this.model = model;
        this.marka = marka;
        this.seriNo = seriNo;
        this.koltukKapasitesi = koltukKapasitesi;
    }

    public String getModel() { return model; }
    public String getMarka() { return marka; }
    public String getSeriNo() { return seriNo; }
    public int getKoltukKapasitesi() { return koltukKapasitesi; }

    @Override
    public String getId() {
        return seriNo;
    }

    @Override
    public void yazdir() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return marka + " " + model + " (Seri No: " + seriNo + ", Kapasite: " + koltukKapasitesi + ")";
    }
}