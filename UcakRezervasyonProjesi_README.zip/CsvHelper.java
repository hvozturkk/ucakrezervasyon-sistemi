import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CsvHelper {

    public static void rezervasyonlariCsvKaydet(List<Rezervasyon> rezervasyonlar, String dosyaAdi) {
        try (FileWriter writer = new FileWriter(dosyaAdi)) {
            writer.write("Ad,Soyad,Yas,UcusTarihi,UcakModeli,UcakSeriNo,Lokasyon\n");
            for (Rezervasyon r : rezervasyonlar) {
                Ucus u = r.getUcus();
                Ucak ucak = u.getUcak();
                Lokasyon l = u.getLokasyon();
                writer.write(String.format("%s,%s,%d,%s,%s,%s,%s\n",
                        r.getAd(),
                        r.getSoyad(),
                        r.getYas(),
                        u.getSaat(),
                        ucak.getModel(),
                        ucak.getSeriNo(),
                        l.getHavaalani()));
            }
            System.out.println("CSV dosyasına başarıyla yazıldı: " + dosyaAdi);
        } catch (IOException e) {
            System.out.println("CSV dosyası yazılamadı: " + e.getMessage());
        }
    }
}