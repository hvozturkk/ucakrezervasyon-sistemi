import java.time.LocalDateTime;

public class Ucus {
    private Lokasyon lokasyon;
    private LocalDateTime saat;
    private Ucak ucak;

    public Ucus(Lokasyon lokasyon, LocalDateTime saat, Ucak ucak) {
        this.lokasyon = lokasyon;
        this.saat = saat;
        this.ucak = ucak;
    }

    public Lokasyon getLokasyon() { return lokasyon; }
    public LocalDateTime getSaat() { return saat; }
    public Ucak getUcak() { return ucak; }

    @Override
    public String toString() {
        return "Uçuş: " + lokasyon + ", Tarih: " + saat + ", Uçak: " + ucak;
    }
}