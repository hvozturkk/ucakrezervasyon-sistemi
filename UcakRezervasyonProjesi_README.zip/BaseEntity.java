public abstract class BaseEntity {
    public abstract String getId();
}